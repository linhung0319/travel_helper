// T86b 第二階段：京都市區飯店 15 間的 judgement（facts/<id>.json 是讀文 subagent 寫的草稿，這裡對應成 judgement 的欄位）。
// 主 session 的判斷：region、meals、nearestStation（geo.mjs walk 的 OSRM 分鐘）、電梯 true/false/null、中文名。
const fs = require('fs');
const KYOTO_TAX = '京都市住宿稅（2026-03-01 起，每人每晚，照每人素泊房價分級，房價不含）：未滿 6,000 円 200 円；6,000～未滿 20,000 円 400 円；20,000～未滿 50,000 円 1,000 円；50,000～未滿 100,000 円 4,000 円；100,000 円以上 10,000 円。一般兒童不免稅';
const walk = JSON.parse(fs.readFileSync(__dirname + '/stations-walk.json', 'utf8'));

// 沒寫、未載之類的一律當 null
const nul = (v) => (v == null || /^(官網)?(未載|沒寫|未找到|null|無資料)/.test(String(v).trim()) || /^（?null）?$/.test(String(v).trim()) ? null : v);
const elevator = (t) => {
  t = nul(t);
  if (!t) return null;
  if (/沒有電梯|無電梯|エレベーターなし/.test(t)) return false;
  if (/(未載|沒寫|未找到|未明|待確認)/.test(t) && !/有電梯|電梯：有|設有電梯/.test(t)) return null;
  return /電梯|エレベーター/.test(t) ? true : null;
};
const num = (t) => (typeof t === 'number' ? t : t == null ? null : Number(String(t).match(/(\d+)\s*(室|間)/)?.[1]) || null);
const maxG = (t) => (t == null ? null : Math.max(0, ...[...String(t).matchAll(/(\d+)\s*名/g)].map((m) => Number(m[1]))) || null);
const phone = (t) => String(t ?? '').match(/0\d{1,4}-\d{1,4}-\d{3,4}/)?.[0] ?? null;

const H = [
  ['kyoto-richmond-ekimae', 'リッチモンドホテルプレミア京都駅前', '京都站前 Richmond Premier', 'kyoto-station', 171941],
  ['kyoto-viscio', 'ホテルヴィスキオ京都 by GRANVIA', 'Hotel Vischio 京都', 'kyoto-station', 168654],
  ['kyoto-hotel-tou', 'hotel tou nishinotoin kyoto', 'hotel tou 西洞院', 'kyoto-station', 181326],
  ['kyoto-nono-shichijo', '天然温泉 蓮花の湯 御宿 野乃 京都七条', '御宿野乃 京都七条', 'kyoto-station', 178613],
  ['kyoto-miyako-hachijo', '都ホテル 京都八条', '都酒店 京都八条', 'kyoto-station', 1160],
  ['kyoto-century', '京都センチュリーホテル', '京都世紀酒店', 'kyoto-station', 1369],
  ['kyoto-dusit-thani', 'デュシタニ京都', '京都都喜天麗酒店', 'kyoto-station', 187320],
  ['kyoto-nikko-princess', 'ホテル日航プリンセス京都', '京都日航公主酒店', 'shijo-nijo', 166],
  ['kyoto-monterey', 'ホテルモントレ京都', '京都蒙特利酒店', 'shijo-nijo', 55347],
  ['kyoto-watazen', '京の宿 綿善旅館', '綿善旅館', 'shijo-nijo', 17903],
  ['kyoto-daiwa-shijo-karasuma', 'ダイワロイネットホテル京都四条烏丸', 'Daiwa Roynet 京都四条烏丸', 'shijo-nijo', 136213],
  ['kyoto-richmond-shijo', 'リッチモンドホテルプレミア京都四条', 'Richmond Premier 京都四条', 'shijo-nijo', 183335],
  ['kyoto-forza-kawaramachi', 'ホテルフォルツァ京都四条河原町', 'Forza 京都四条河原町', 'shijo-nijo', 182567],
  ['kyoto-good-nature', 'GOOD NATURE HOTEL KYOTO', 'Good Nature Hotel 京都', 'shijo-nijo', 176768],
  ['kyoto-super-hotel-kawaramachi', '天然温泉 御所の湯 スーパーホテル京都・四条河原町', 'Super Hotel 京都四条河原町', 'shijo-nijo', 75325],
];

const J = H.map(([id, ja, zh, region, no]) => {
  const f = JSON.parse(fs.readFileSync(`${__dirname}/facts/${id}.json`, 'utf8'));
  // 最近車站：兩個候選取 OSRM 分鐘少的
  const cand = (walk[id] ?? []).map((s) => { const [sid, m] = s.split(' '); return { id: sid, minutes: Math.max(1, Math.round(parseFloat(m))) }; }).sort((a, b) => a.minutes - b.minutes);
  const st = cand[0] ?? null;
  const access = nul(f.access);
  const ryokan = f.kind === 'ryokan';
  const extra = {
    breakfast: nul(f.meals),
    dinner: nul(f.dinnerVenue),
    onsen: nul(f.onsen),
    stationAccess: access,
    febNote: nul(f.febNote),
    taxes: KYOTO_TAX,
    conflicts: f.conflicts ?? [],
  };
  for (const k of Object.keys(extra)) if (extra[k] == null) delete extra[k];
  return {
    id, name: { ja, zh }, googleKey: id, region, kind: ryokan ? 'ryokan' : 'hotel', rakutenHotelNo: no,
    meals: ryokan ? 'dinner+breakfast' : 'varies',
    nearestStation: st ? { id: st.id, mode: 'walk', minutes: st.minutes, note: `${access ? '官網：' + access.slice(0, 90) + '；' : ''}路線估算 ${st.minutes} 分` } : null,
    luggage: nul(f.luggage), pickup: null, officialPrices: [],
    checkIn: nul(f.checkIn), checkOut: nul(f.checkOut), photos: [],
    links: { official: f.official, ...(f.instagram ? { instagram: f.instagram } : {}) },
    group: {
      totalRooms: num(f.totalRooms), roomTypes: f.roomTypes ?? [], maxGuests: maxG(f.maxGuests), wholeRental: false, pickupCapacity: null,
      note: nul(f.groupPlan),
    },
    accessibility: { elevator: elevator(f.elevator), beds: nul(f.beds), stairs: nul(f.stairs), kids: nul(f.kids), note: nul(f.accessibility) },
    reservation: { methods: ['official', 'rakuten', ...(phone(f.reservation) ? ['phone'] : [])], phone: phone(f.reservation), url: f.official, groupNote: nul(f.groupPlan) },
    extra,
  };
});
fs.writeFileSync(__dirname + '/judgement-kyoto-hotels.json', JSON.stringify(J, null, 1));
for (const j of J) console.log(j.id, j.nearestStation?.id, j.nearestStation?.minutes, 'elev', j.accessibility.elevator, 'rooms', j.group.totalRooms, 'max', j.group.maxGuests, 'tel', j.reservation.phone);
