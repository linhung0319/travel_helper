// T86b 第二階段：京都飯店 15 間（included，build 會補 pointId）、備選 8 間（over-limit）、楽天一棟貸し 10 間（not-included）加進候選
import fs from 'node:fs';
import { readJson, writeJson } from '../../../../scripts/lib/json-file.mjs';
const FILE = 'data/raw/kyoto/candidates/lodging.json';
const { data: list, eol } = readJson(FILE);
const rk = {};
for (const f of ['party-kyotost', 'party-karasuma', 'party-kawaramachi']) for (const h of JSON.parse(fs.readFileSync(`data/cache/work/t86b-1/rk/${f}.json`, 'utf8')).hotels) rk[h.hotelNo] ??= h;
const g = Object.fromEntries(fs.readFileSync('data/cache/work/t86b-1/google.jsonl', 'utf8').trim().split('\n').map(JSON.parse).map((x) => [x.key, x]));
const DATE = '2026-11-12';
const combos = (no) => {
  const by = {};
  for (const v of rk[no]?.vacancies ?? []) (by[v.date] ??= new Set()).add(v.combo);
  return Object.entries(by).map(([d, s]) => `${d.slice(5)} ${[...s].join('、')}`).join('；');
};
const minPP = (no) => Math.min(...(rk[no]?.vacancies ?? []).map((v) => v.cheapest?.perPerson ?? Infinity));
const add = (c) => { const i = list.findIndex((x) => x.key === c.key); if (i >= 0) list[i] = c; else list.push(c); };
const IN = [
  ['kyoto-richmond-ekimae', 171941, 'kyoto-station'], ['kyoto-viscio', 168654, 'kyoto-station'], ['kyoto-hotel-tou', 181326, 'kyoto-station'],
  ['kyoto-nono-shichijo', 178613, 'kyoto-station'], ['kyoto-miyako-hachijo', 1160, 'kyoto-station'], ['kyoto-century', 1369, 'kyoto-station'],
  ['kyoto-dusit-thani', 187320, 'kyoto-station'], ['kyoto-nikko-princess', 166, 'shijo-nijo'], ['kyoto-monterey', 55347, 'shijo-nijo'],
  ['kyoto-watazen', 17903, 'shijo-nijo'], ['kyoto-daiwa-shijo-karasuma', 136213, 'shijo-nijo'], ['kyoto-richmond-shijo', 183335, 'shijo-nijo'],
  ['kyoto-forza-kawaramachi', 182567, 'shijo-nijo'], ['kyoto-good-nature', 176768, 'shijo-nijo'], ['kyoto-super-hotel-kawaramachi', 75325, 'shijo-nijo'],
];
for (const [key, no, region] of IN) {
  const h = rk[no];
  add({ key, name: { ja: g[key]?.name ?? h.name }, region, category: key === 'kyoto-watazen' ? 'ryokan' : 'hotel', status: 'included', criteria: [], reason: null, pointId: null,
    ratings: { rakuten: h.reviewAverage, rakutenReviews: h.reviewCount, google: g[key]?.rating ?? null, googleReviews: g[key]?.reviews ?? null },
    links: {}, note: `楽天 No. ${no}；15 人組合（${combos(no)}）；最低每人 ${minPP(no).toLocaleString()} 円（楽天 ${DATE}）` });
}
const OVER = [
  [104701, 'kyoto-station', 'ドーミーインPREMIUM京都駅前（天然溫泉）'], [153230, 'kyoto-station', null], [13758, 'kyoto-station', '都和旅館（和室 3～5 人房）'],
  [108, 'kyoto-station', null], [160991, 'higashiyama', null], [162930, 'higashiyama', null], [167802, 'shijo-nijo', null], [165176, 'shijo-nijo', '2/10 只剩 8x2'],
];
for (const [no, region, memo] of OVER) {
  const h = rk[no];
  add({ key: `kyoto-rk-${no}`, name: { ja: h.name.normalize('NFKC') }, region, category: no === 13758 ? 'ryokan' : 'hotel', status: 'over-limit', criteria: [],
    reason: '京都飯店 15 間的名額外：👤 2026-11-12 確認清單時選了其他 15 間，這間列為備選',
    pointId: null, ratings: { rakuten: h.reviewAverage, rakutenReviews: h.reviewCount }, links: {},
    note: `楽天 No. ${no}；15 人組合（${combos(no)}）；最低每人 ${minPP(no).toLocaleString()} 円（楽天 ${DATE}）${memo ? '；' + memo : ''}` });
}
const MACHIYA = [
  [190325, '清水小筑', 'higashiyama', '楽天頁沒列許可番號；最多 14 人，不到 15 人'],
  [200788, 'AUR Kyoto（民泊）', 'shijo-nijo', '楽天頁沒列届出番号，兒童收不收沒寫；楽天頁寫最多 15 人，唯一人數夠的（要問番號：楽天的詢問或電話）'],
  [180050, '籠／rou', 'shijo-nijo', '楽天頁沒列許可番號；一棟最多 10 人，同業者附近的棟沒列'],
  [179244, 'たわら庵（東館・西館）', 'shijo-nijo', '楽天頁沒列許可番號；兩棟的定員沒寫'],
  [168200, '至誠宿 大宮五条', 'kyoto-station', '楽天頁沒列許可番號；3 室合計 10 人；頁面寫段差多，不適合長輩'],
  [167538, '京都旅庵 然', 'higashiyama', '楽天頁沒列許可番號；人數、業者沒寫'],
  [167539, '東山 粟田庵', 'okazaki', '楽天頁沒列許可番號；人數、業者沒寫'],
  [146870, '古都庵', 'shijo-nijo', '楽天頁沒列許可番號；方案寫 10 名まで'],
  [179672, '別邸樹下', 'shijo-nijo', '楽天頁沒列許可番號；人數、業者沒寫'],
  [199547, '井ノ口 別邸（民泊）', 'shijo-nijo', '楽天頁沒列届出番号；人數、業者沒寫'],
];
for (const [no, ja, region, why] of MACHIYA) add({ key: `kyoto-machiya-rk-${no}`, name: { ja }, region, category: 'rental-house', status: 'not-included', criteria: [],
  reason: `町家：照 CONVENTIONS「京都、琵琶湖的做法」只收頁面上有旅館業許可或住宿事業届出番号的；${why}（${DATE}）`, pointId: null, ratings: {},
  links: {}, note: `楽天 No. ${no}；楽天 vacant --rooms 1 --adults 10（2027-02-09、02-10）有空房的一棟貸し；位置（region）是大致判斷` });
writeJson(FILE, list, eol);
console.log('candidates', list.length);
