// T86b：build-lodging.mjs 之後跑，在京都每筆 prices 的 note 後面加京都市住宿稅（2026-03-01 起的級距）。重跑 build 之後要再跑一次。
import { readJson, writeJson } from '../../../../scripts/lib/json-file.mjs';
const F = 'data/areas/kyoto/lodging.json';
const { data, eol } = readJson(F);
const tier = (p) => (p < 6000 ? 200 : p < 20000 ? 400 : p < 50000 ? 1000 : p < 100000 ? 4000 : 10000);
let n = 0;
for (const x of data) for (const p of x.prices ?? []) {
  p.note = (p.note ?? '').replace(/另加京都市住宿稅.*$/, '');
  const roomOnly = /^素泊/.test(p.plan ?? '') && p.unit === 'per-person' && p.adult != null;
  const add = roomOnly
    ? `另加京都市住宿稅每人每晚 ${tier(p.adult).toLocaleString()} 円（素泊每人 ${p.adult.toLocaleString()} 円這一級；實際照不含消費稅的素泊房價分級）`
    : '另加京都市住宿稅（每人每晚，照每人素泊房價分級：未滿 6,000 円 200 円、未滿 2 萬 400 円、未滿 5 萬 1,000 円、未滿 10 萬 4,000 円、10 萬以上 10,000 円）';
  p.note = (p.note ? p.note.replace(/。?$/, '。') : '') + add;
  n++;
}
writeJson(F, data, eol);
console.log(`加了 ${n} 筆`);
