const fs=require('fs');let b=fs.readFileSync(process.argv[2]);let s=b.toString('utf8');if(s.includes('�'))s=new TextDecoder('shift_jis').decode(b);
s=s.replace(/<script[\s\S]*?<\/script>/g,'').replace(/<style[\s\S]*?<\/style>/g,'').replace(/<[^>]*>/g,'\n').replace(/&amp;/g,'&');
let l=s.split('\n').map(x=>x.trim()).filter(Boolean);let i=l.findIndex(x=>x==='SCROLL');console.log(l.slice(i>0?i:0).join('\n'));
